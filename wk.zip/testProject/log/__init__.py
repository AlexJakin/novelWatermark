class MyLogging:
    pass